@echo off
rem ==========================================================================
rem  Instala o Agente WRPdv neste servidor, para o usuário logado.
rem  - copia o agente-wrpdv.exe para C:\wrpdv\Monitor
rem  - mantém o agente.toml que já existir lá (configuração do cliente)
rem  - faz o agente abrir junto com o login do Windows
rem  - abre o agente (o painel abre no navegador)
rem ==========================================================================
setlocal
set "DESTINO=C:\wrpdv\Monitor"

if not exist "%~dp0agente-wrpdv.exe" (
    echo Nao encontrei o agente-wrpdv.exe ao lado deste arquivo.
    pause
    exit /b 1
)

taskkill /IM agente-wrpdv.exe /F >nul 2>&1
if not exist "%DESTINO%" mkdir "%DESTINO%"
copy /Y "%~dp0agente-wrpdv.exe" "%DESTINO%\" >nul || (echo Falha ao copiar o agente. & pause & exit /b 1)
if exist "%~dp0agente.toml" if not exist "%DESTINO%\agente.toml" copy /Y "%~dp0agente.toml" "%DESTINO%\" >nul

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v AgenteWRPdv /t REG_SZ /d "\"%DESTINO%\agente-wrpdv.exe\"" /f >nul

start "" "%DESTINO%\agente-wrpdv.exe"
echo.
echo Agente instalado em %DESTINO% e configurado para abrir com o Windows.
echo Painel: http://localhost:8770   (configuracao: %DESTINO%\agente.toml)
echo.
pause
