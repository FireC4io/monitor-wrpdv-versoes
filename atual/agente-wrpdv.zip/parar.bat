@echo off
rem Fecha o Agente WRPdv (ele volta a abrir no próximo login).
taskkill /IM agente-wrpdv.exe /F
pause
