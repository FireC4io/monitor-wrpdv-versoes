@echo off
rem Fecha o Agente WRPdv e tira do início automático. A pasta C:\wrpdv\Monitor
rem (configuração e dados coletados) é mantida.
taskkill /IM agente-wrpdv.exe /F >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v AgenteWRPdv /f >nul 2>&1
echo Agente fechado e retirado do inicio automatico. A pasta C:\wrpdv\Monitor foi mantida.
pause
